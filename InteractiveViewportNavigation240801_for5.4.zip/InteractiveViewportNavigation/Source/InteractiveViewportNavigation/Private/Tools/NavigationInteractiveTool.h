// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#pragma once

#include "CoreMinimal.h"

#include "InteractiveToolBuilder.h"
//#include "BaseGizmos/GizmoElementArrow.h"
#include "BaseTools/ClickDragTool.h"
#include "EditorGizmos/TransformGizmo.h"
#include "NavigationInteractiveTool.generated.h"

class UNavigationElement;
/**
 * Builder for UNavigationInteractiveTool
 */
UCLASS()
class INTERACTIVEVIEWPORTNAVIGATION_API UNavigationInteractiveToolBuilder : public UInteractiveToolBuilder
{
	GENERATED_BODY()

public:
	virtual bool CanBuildTool(const FToolBuilderState& SceneState) const override { return true; }
	virtual UInteractiveTool* BuildTool(const FToolBuilderState& SceneState) const override;
};

//继承自UInteractiveTool和IClickDragBehaviorTarget, 响应点击拖拽事件
UCLASS()
class INTERACTIVEVIEWPORTNAVIGATION_API UNavigationInteractiveTool : public UInteractiveTool, public IHoverBehaviorTarget, public IClickDragBehaviorTarget
{
	GENERATED_BODY()
public:

	/** UInteractiveTool overrides */
	virtual void Setup() override; 
	//virtual void Render(IToolsContextRenderAPI* RenderAPI) override;
	//virtual void OnPropertyModified(UObject* PropertySet, FProperty* Property) override;
	//virtual void OnTick(float DeltaTime) override;

	// IHoverBehaviorTarget implementation
	virtual FInputRayHit BeginHoverSequenceHitTest(const FInputDeviceRay& DevicePos) override;
	virtual void OnBeginHover(const FInputDeviceRay& DevicePos) override;
	virtual bool OnUpdateHover(const FInputDeviceRay& DevicePos) override {return false;}
	//不能在onend时设置hover材质, 因为调用OnEndHover时LastHitPart已经为default了.
	//HitTarget->UpdateHoverState(false,static_cast<uint32>(LastHitPart));
	virtual void OnEndHover() override {};

	//如果加上click行为, drag直接失效, 故只能用此实现
	/** IClickDragBehaviorTarget implementation */
	virtual FInputRayHit CanBeginClickDragSequence(const FInputDeviceRay& PressPos) override;
	virtual void OnClickPress(const FInputDeviceRay& PressPos) override;
	virtual void OnClickDrag(const FInputDeviceRay& DragPos) override;
	virtual void OnClickRelease(const FInputDeviceRay& ReleasePos) override;
	virtual void OnTerminateDragSequence() override {}

private:

	/** Setup behaviors ,该函数注册,初始化交互行为的对象,在工具的Setup()执行,使交互生效(
	 * 即重写接口的On XXX虚函数,要在SetupBehaviors执行后才有效), */
	void SetupBehaviors();
	
public:

	TSharedPtr<class SNavigationManagerWidget> ManagerWidget;

private:

	FEditorViewportClient* EditorViewportClient = nullptr;

	bool CanExecuteClick = false;

	FVector2D DragInitialPosition;
	FVector2D DragLastPosition;

	int ViewSizeX;
	int ViewSizeY;

	bool RotateInNextTime = true;
	
	UPROPERTY()
	ETransformGizmoPartIdentifier LastHitPart = ETransformGizmoPartIdentifier::Default;
};
